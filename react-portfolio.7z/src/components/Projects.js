import React from 'react';
import Thumbnail from './Thumbnail';
import netflix from '../images/netflix.jpg'
import stockNews from '../images/pexels-stock.jpg'
import weatherDashboard from '../images/weather-dashboard.jpg'

function Projects(props) {
  return (
      <div className={'container'}>
        <div className={'row'}>
          <div className={'col-md-9'}>
            <div className={'card'}>
            <div className={'row'}>
              <Thumbnail
                  href='https://glacial-shore-36326.herokuapp.com/ '
                  image={netflix}
                  title='Subscription Tracker'
              />
              <Thumbnail
                  href='https://mannylouhub.github.io/Stock-News-App/'
                  image={stockNews}
                  title='Stock-New-App'
              />
            </div>
            <div className={'row'}>
              <Thumbnail
                  href=' https://mannylouhub.github.io/Weather-Dashboard/ '
                  image={weatherDashboard}
                  title='Weather Dashboard'
              />
            </div>
          </div>
        </div>
          <div className={'col-md-3'}>
            <div className={'card'}>
            Description
          </div>
        </div>
      </div>

      </div>
  )
}


export default Projects;