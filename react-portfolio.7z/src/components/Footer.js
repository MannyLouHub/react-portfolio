import React from "react";

function Footer(props) {
  return (
      <div className = "footer p-1">
        ©Copyright
      </div>
  )
}

export default Footer;