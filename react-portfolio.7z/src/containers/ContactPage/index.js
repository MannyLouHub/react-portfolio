import React from 'react';

const ContactPage = () => {
  return <div>Contact Page</div>
}
export default ContactPage;